const userRecommend = document.querySelector('.user-recommend')

const textInput = document.querySelector('.text-input')

const sendBtn = document.querySelector('.send-btn')

const container = document.querySelector('.container')



sendBtn.addEventListener("click",function () {
      
     
      if (textInput.value == "") {
          return false
      }
      const userRespond = textInput.value
      chat(userRespond)
      
      render()
      
      xhr()  
      
})


userRecommend.addEventListener("click", function (e){

      if(e.target.matches(".child")) {
          const userRespond = e.target.innerText
       chat(userRespond)
       }
        
       
    
    })

function render() {
    textInput.value = ""
}

/* ======== XMLHttpResquest ============ */

function xhr() {
    const xhr = new XMLHttpRequest()
    
    
    xhr.open('GET','data.json',true)
    xhr.onload = function () {
    
    if (this.status == 200) {
    const array = JSON.parse(xhr.responseText); 
    
         }
       
    }
    xhr.send()
}













/* -------------- time  -----------------*/

const chatTime = document.querySelector('.time')
chatTime.innerText = time()

function time(){
    let date = new Date()
let hrs = date.getHours()
let min = date.getMinutes()
let timePeriod = "AM";

if (hrs >= 12) {
    timePeriod = "PM" 
}
if (hrs > 12) {
    hrs = hrs - 12;
}else{
    hrs = "0" + hrs;
}
if (min < 10) {
   min = "0" + min; 
}

let time = `${hrs}:${min} ${timePeriod}`

return time
}


/* ------- user chat ------------ */

function chat(text){
    const userChat = document.createElement('div')
    userChat.className = "chat"
    userChat.classList.add("user")
    container.appendChild(userChat)
    
    const userMessage = document.createElement('div')
    userMessage.className = "message"
    userChat.appendChild(userMessage)
    
    const userText = document.createElement('div')
    userText.className = "text"
    userText.innerText =  text
    userMessage.appendChild(userText)
    
    const sendTime = document.createElement('div')
    sendTime.className = "time"
    sendTime.innerText = time()
    userMessage.appendChild(sendTime)
    }

/* --------- bot chat ----------------- */

function botChat(text){
    const botChat = document.createElement('div')
    botChat.className = "chat"
    botChat.classList.add("respondent")
    container.appendChild(botChat)
    
    const botMessage = document.createElement('div')
    botMessage.className = "message"
    botChat.appendChild(botMessage)
    
    const botText = document.createElement('div')
    botText.className = "text"
    botText.innerText =  text
    botMessage.appendChild(botText)
    
    const sendTime = document.createElement('div')
    sendTime.className = "time"
    sendTime.innerText = time()
    botMessage.appendChild(sendTime)
    }

/* --------------------------------- */
/* ----- dark mode & light mode -----*/
/* --------------------------------- */

const menu = document.querySelector('.menu')
const panel = document.querySelector('.main-panel')

menu.addEventListener('click',function () {
    if (panel.classList.contains('hide')) {
        panel.classList.remove('hide')
    }
    else{
       panel.classList.add('hide') 
    }
})


const theme = document.querySelector('.theme')

const themeIcon = document.querySelector('.theme-icon')

const themeName = document.querySelector('.theme-name')

const body = document.querySelector('body')

theme.addEventListener('click',function () {
    if (body.classList.contains('dark-mode')) {
        body.classList.remove('dark-mode')
        themeIcon.src = "light-mode-icon.svg"
        themeName.innerText = "Light mode"
    }
    else{
       body.classList.add('dark-mode')
       themeName.innerText = "Dark mode"
       themeIcon.src = "dark-mode-icon.svg"
    }
})



/* ---------------------------------- */
/* ---------clear conversation ----- */


const clearConversation = document.querySelector('.clear-conversation')


clearConversation.addEventListener('click',function () {

const elements = document.getElementsByClassName('chat')
    while(elements.length > 0){ container.removeChild(elements[0]);
  }
  botChat("Hey, how's it going?😄")
})


/* ---------------------------------- */
/* --------- rock paper scirror ----- */

const rps = document.querySelector('.rps')
const rpsChoice = document.querySelector('.rps-choice')

rps.addEventListener('click',game)

function game() {
    const userRespond = rps.innerText
    chat(userRespond)
    const text = "let's play"
    botChat(text)
    rpsUserChoices()
    play()
    
    
}


function rpsUserChoices() {
    if (rpsChoice.classList.contains('hide')) {
        rpsChoice.classList.remove('hide')
    }
    else{
       rpsChoice.classList.add('hide') 
    }
}

function hideRecommendations() {
    
    
    userRecommend.classList.toggle("hide");
    
}

function play(){
     rpsChoice.addEventListener('click',function (e) {
     
    let botChoice = ["rock","paper","scissors"]
    let random = Math.floor(Math.random() * botChoice.length)
     
       
     


if (e.target.className == "stop" || textInput.value == "stop") {
    chat("let's stop")
    botChat("Ok, let play another time")
    rpsUserChoices()
        
}
else if (e.target.className =="scissors") {
         chat("scissors ✌️")
            botChat(botChoice[random])
             if (botChoice[random] == "paper") {
                botChat('you won 😒 and I lost')
            }
           else if (botChoice[random] == "rock") {
                botChat('you lost buddy😏 and I won')
            }
            else{
                botChat('its draw 🥴, I will make sure you lose next time')
            }
     }
      else if (e.target.className =="paper") {
         chat("paper 🖐️")
            botChat(botChoice[random])
            if (botChoice[random] == "scissors") {
                botChat('you won 😒 and I lost')
            }
            else if (botChoice[random] == "rock") {
                botChat('you lost buddy😏 and I won')
            }
            else{
                botChat('its draw 🥴, I will make sure you lose next time')
            }
     }
     
     
     else if (e.target.className =="rock") {
         chat("rock ✊")
            botChat(botChoice[random])
            if (botChoice[random] == "paper") {
                botChat('you won 😒 and I lost')
            }
            else if (botChoice[random] == "scissors") {
                botChat('you lost buddy😏 and I won')
            }
            else{
                botChat('its draw 🥴, I will make sure you lose next time')
            }
     }

        
        
    })
}


/* ============ ====== jokes ============= */


const jokesChoice = document.querySelector('.jokes-choice')

function jokeChoices() {
    if (jokesChoice.classList.contains('hide')) {
        jokesChoice.classList.remove('hide')
    }
    else{
       jokesChoice.classList.add('hide') 
    }
}
